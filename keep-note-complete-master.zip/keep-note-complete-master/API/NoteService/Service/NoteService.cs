﻿using System;
using System.Collections.Generic;
using NoteService.Exceptions;
using NoteService.Models;
using NoteService.Repository;

namespace NoteService.Service
{
    public class NoteService : INoteService
    {
        //define a private variable to represent repository

        //Use constructor Injection to inject all required dependencies.
        private readonly INoteRepository noteRepository;
        public NoteService(INoteRepository _noteRepository)
        {
            this.noteRepository = _noteRepository;
        }
        
        
        //This method should be used to create a new note.
        public bool CreateNote(Note note)
        {
            return noteRepository.CreateNote(note);
        }

        //This method should be used to delete an existing note for a user
        public bool DeleteNote(string userId, int noteId)
        {
            try
            {
                Note notes = noteRepository.GetNoteByNoteId(userId, noteId);
                if (notes == null)
                    throw new NoteNotFoundExeption($"NoteId {noteId} for user {userId} does not exist");
                else
                    return noteRepository.DeleteNote(userId, noteId);
            }
            catch (Exception)
            {
                throw new NoteNotFoundExeption($"NoteId {noteId} for user {userId} does not exist");
            }
        }

        //This methos is used to retreive all notes for a user
        public List<Note> GetAllNotesByUserId(string userId)
        {
            return noteRepository.FindAllNotesByUser(userId);
        }

        public Note GetNoteByNoteId(string userId, int noteId)
        {
            return noteRepository.GetNoteByNoteId(userId, noteId);
        }

        //This method is used to update an existing note for a user        
        public Note UpdateNote(int noteId, string userId, Note note)
        {
            Note note1 = new Note();
            if (noteRepository.GetNoteByNoteId(userId, noteId) == null)
                throw new NoteNotFoundExeption();
            if (noteRepository.GetNoteByNoteId(userId, noteId) != null)
                noteRepository.UpdateNote(noteId, userId, note);
            note1 = noteRepository.GetNoteByNoteId(userId, noteId);
            return note1;
        }

    }
}
