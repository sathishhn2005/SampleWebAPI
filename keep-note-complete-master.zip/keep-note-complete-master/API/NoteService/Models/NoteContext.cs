﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace NoteService.Models
{
    public class NoteContext
    {
        //declare variables to connect to MongoDB database
        MongoClient mongoClient;
        IMongoDatabase database;
        public NoteContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database From Enivronment Variable
            string constr = Environment.GetEnvironmentVariable("mongodb");
            string db = Environment.GetEnvironmentVariable("NoteDatabase");
            //Initialize MongoClient and Database using connection string and database name from configuration
            if (constr == null)
                constr = configuration.GetSection("MongoDB:ConnectionString").Value;
            if (db == null)
                db = configuration.GetSection("MongoDB:NoteDatabase").Value;

            //Initialize MongoClient and Database using connection string and database name from configuration
            mongoClient = new MongoClient(constr);
            database = mongoClient.GetDatabase(db);

        }

        //Define a MongoCollection to represent the Notes collection of MongoDB based on NoteUser type
        public IMongoCollection<NoteUser> Notes => database.GetCollection<NoteUser>("Notes");
    }
}
