﻿using System;
using System.Collections.Generic;
using CategoryService.Models;
using CategoryService.Repository;
using CategoryService.Exceptions;
using MongoDB.Driver;
using System.Linq;

namespace CategoryService.Service
{
    public class CategoryService:ICategoryService
    {
        //define a private variable to represent repository
        private readonly ICategoryRepository repository;
        //Use constructor Injection to inject all required dependencies.
        public CategoryService(ICategoryRepository categoryRepository)
        {
            repository = categoryRepository;

        }

        //This method should be used to save a new category.
        public Category CreateCategory(Category category)
        {
            var cat = repository.GetAllCategoriesByUserId(category.CreatedBy).Find(x => x.Id == category.Id);
            if (cat != null)
                throw new CategoryNotCreatedException("This category already exists");
            return repository.CreateCategory(category);

        }
        //This method should be used to delete an existing category.
        public bool DeleteCategory(int categoryId)
        {
            try
            {
                if (repository.DeleteCategory(categoryId))
                    return true;
                else
                    throw new CategoryNotFoundException("This category id not found");
            }
            catch
            {
                throw new CategoryNotFoundException("This category id not found");
            }
        }

        // This method should be used to get all category by userId
        public List<Category> GetAllCategoriesByUserId(string userId)
        {
            return repository.GetAllCategoriesByUserId(userId);
        }
        //This method should be used to get a category by categoryId.
        public Category GetCategoryById(int categoryId)
        {
            var Category = repository.GetCategoryById(categoryId);
            if (Category != null)
            {
                return repository.GetCategoryById(categoryId);
            }
            else
                throw new CategoryNotFoundException("This category id not found");
        }
        //This method should be used to update an existing category.
        public bool UpdateCategory(int categoryId, Category category)
        {
            var Category = repository.GetCategoryById(categoryId);
            if (Category != null)
            {
                repository.UpdateCategory(categoryId, category);
                return true;
            }
            else
                throw new CategoryNotFoundException("This category id not found");
        }
    }
}
