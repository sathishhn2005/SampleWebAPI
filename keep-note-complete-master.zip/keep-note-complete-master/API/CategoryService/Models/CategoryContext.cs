﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace CategoryService.Models
{
    public class CategoryContext
    {
        //declare variable to connect to MongoDB database
        MongoClient mongoClient;
        IMongoDatabase database;
        public CategoryContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database From Enivronment Variable
            string constr = Environment.GetEnvironmentVariable("mongodb");
            string db = Environment.GetEnvironmentVariable("CategoryDatabase");
            //Initialize MongoClient and Database using connection string and database name from configuration
            if (constr == null)
                constr = configuration.GetSection("MongoDB:ConnectionString").Value;
            if (db == null)
                db = configuration.GetSection("MongoDB:CategoryDatabase").Value;

            //Initialize MongoClient and Database using connection string and database name from configuration
            mongoClient = new MongoClient(constr);
            database = mongoClient.GetDatabase(db);                       
        }

        //Define a MongoCollection to represent the Categories collection of MongoDB
        public IMongoCollection<Category> Categories => database.GetCollection<Category>("Categories");
    }
}
