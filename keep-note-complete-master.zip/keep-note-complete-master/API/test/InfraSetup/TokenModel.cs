﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test.InfraSetup
{
    public class TokenModel
    {
        public string Token { get; set; }
    }
}
