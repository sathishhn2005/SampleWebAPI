﻿using System;
using UserService.Exceptions;
using UserService.Models;
using UserService.Repository;

namespace UserService.Service
{
    public class UserService : IUserService
    {
        //define a private variable to represent repository

        //Use constructor Injection to inject all required dependencies.
        private readonly IUserRepository userrepository;

        public UserService(IUserRepository repository)
        {
            userrepository = repository;
        }

        //This method should be used to delete an existing user.
        public bool DeleteUser(string userId)
        {
            var users = userrepository.GetUserById(userId);
            if (users != null)
            {
                userrepository.DeleteUser(userId);
                return true;
            }
            else
                throw new UserNotFoundException("This user id does not exist");
        }
        
        public User GetUserById(string userId)
        {
            var user = userrepository.GetUserById(userId);
            if (user != null)
                return user;
            else
                throw new UserNotFoundException("This user id does not exist");
        }
        //This method is used to register a new user
        public User RegisterUser(User user)
        {
            if (userrepository.GetUserById(user.UserId) != null)
                throw new UserNotCreatedException("This user id already exists");
            return userrepository.RegisterUser(user);
        }
        //This methos is used to update an existing user
        public bool UpdateUser(string userId, User user)
        {
            var users = userrepository.GetUserById(userId);

            if (users != null)
            {
                userrepository.UpdateUser(userId, user);
                return true;
            }
            else
                throw new UserNotFoundException("This user id does not exist");
        }
    }
}
