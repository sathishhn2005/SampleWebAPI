﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace UserService.Models
{
    public class UserContext
    {
        //declare variable to connect to MongoDB database
        MongoClient mongoClient;
        IMongoDatabase database;
        public UserContext(IConfiguration configuration)
        {
            //Initialize MongoClient and Database From Enivronment Variable
            string constr = Environment.GetEnvironmentVariable("mongodb");
            string db = Environment.GetEnvironmentVariable("UserDatabase");

            //Initialize MongoClient and Database using connection string and database name from configuration
            if (constr == null)
                constr = configuration.GetSection("MongoDB:ConnectionString").Value;
            if (db == null)
                db = configuration.GetSection("MongoDB:UserDatabase").Value;

            mongoClient = new MongoClient(constr);
            database = mongoClient.GetDatabase(db);
        }

        //Define a MongoCollection to represent the Users collection of MongoDB
        public IMongoCollection<User> Users => database.GetCollection<User>("Users");
    }
}
