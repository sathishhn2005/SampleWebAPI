﻿using System;
using System.Linq;
using MongoDB.Driver;
using UserService.Models;

namespace UserService.Repository
{
    public class UserRepository:IUserRepository
    {
        //define a private variable to represent UserContext
        private readonly UserContext context;
        public UserRepository(UserContext _context)
        {
            this.context = _context;
        }
        //This method should be used to delete an existing user.
        public bool DeleteUser(string userId)
        {
            var deleteResult = context.Users.DeleteOne(x => x.UserId == userId);
            return deleteResult.IsAcknowledged && deleteResult.DeletedCount > 0;
        }

        //This method should be used to delete an existing user
        public User GetUserById(string userId)
        {
            return context.Users.Find(x => x.UserId == userId).FirstOrDefault();
        }
        //This method is used to register a new user
        public User RegisterUser(User user)
        {
            context.Users.InsertOne(user);
            return user;
        }
        //This methos is used to update an existing user
        public bool UpdateUser(string userId, User user)
        {
            //{ UserId = "Mukesh", Name = "Mukesh", Contact = "9822445566", AddedDate = DateTime.Now };
            var filter = Builders<User>.Filter.Where(c => c.UserId == userId);
            var update = Builders<User>.Update
                        .Set(x => x.UserId, user.UserId)
                        .Set(x => x.Name, user.Name)
                        .Set(x => x.Contact, user.Contact);

            //var updateResult = context.Customers.UpdateOne(filter, update);
            var updateResult = context.Users.ReplaceOne(filter, user);
            return updateResult.IsAcknowledged && updateResult.ModifiedCount > 0;
        }
    }
}
