﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;

namespace ReminderService.Models
{
    public class ReminderContext
    {
        //declare variables to connect to MongoDB database
        MongoClient mongoClient;
        IMongoDatabase database;
        public ReminderContext(IConfiguration configuration)
        {

            //Initialize MongoClient and Database From Enivronment Variable
            string constr = Environment.GetEnvironmentVariable("mongodb");
            string db = Environment.GetEnvironmentVariable("ReminderDatabase");

            //Initialize MongoClient and Database using connection string and database name from configuration
            if (constr == null)
                constr = configuration.GetSection("MongoDB:ConnectionString").Value;
            if (db == null)
                db = configuration.GetSection("MongoDB:ReminderDatabase").Value;

            //Initialize MongoClient and Database using connection string and database name from configuration
            mongoClient = new MongoClient(constr);
            database = mongoClient.GetDatabase(db);
        }

        //Define a MongoCollection to represent the Reminders collection of MongoDB
        public IMongoCollection<Reminder> Reminders => database.GetCollection<Reminder>("Reminders");
    }
}

