﻿using System;
using System.Collections.Generic;
using System.Linq;
using MongoDB.Driver;
using ReminderService.Models;

namespace ReminderService.Repository
{
    public class ReminderRepository:IReminderRepository
    {
        private readonly ReminderContext context;
        //define a private variable to represent ReminderContext
        public ReminderRepository(ReminderContext _context)
        {
            this.context = _context;
        }
        //This method should be used to save a new reminder.
        public Reminder CreateReminder(Reminder reminder)
        {
            //reminder Id should be auto generated and must start from 201    
            //Reminder rem = GetAllRemindersByUserId("Mukesh").OrderByDescending(x => x.Id).FirstOrDefault();            
            Reminder rem = context.Reminders.Find(x => x.Id > 0).ToList().OrderByDescending(x => x.Id).FirstOrDefault();
            if (rem == null)
                reminder.Id = 201;
            if (rem != null)
                reminder.Id = rem.Id + 1;
            context.Reminders.InsertOne(reminder);
            return reminder;
        }
        //This method should be used to delete an existing reminder.
        public bool DeleteReminder(int reminderId)
        {
            var deleteResult = context.Reminders.DeleteOne(x => x.Id == reminderId);
            return deleteResult.IsAcknowledged && deleteResult.DeletedCount > 0;
        }
        //This method should be used to get all reminders by userId
        public List<Reminder> GetAllRemindersByUserId(string userId)
        {
            return context.Reminders.Find(x => x.CreatedBy == userId).ToList();
        }
        //This method should be used to get a reminder by reminderId
        public Reminder GetReminderById(int reminderId)
        {
            return context.Reminders.Find(x => x.Id == reminderId).FirstOrDefault();
        }
        // This method should be used to update an existing reminder.
        public bool UpdateReminder(int reminderId, Reminder reminder)
        {
            var filter = Builders<Reminder>.Filter.Where(c => c.Id == reminderId);

            var update = Builders<Reminder>.Update
                        .Set(x => x.Id, reminder.Id)
                        .Set(x => x.Name, reminder.Name)
                        .Set(x => x.Description, reminder.Description)
                        .Set(x => x.Type, reminder.Type)
                        .Set(x => x.CreatedBy, reminder.CreatedBy);

            //var updateResult = context.Customers.UpdateOne(filter, update);
            var updateResult = context.Reminders.ReplaceOne(filter, reminder);
            return updateResult.IsAcknowledged && updateResult.ModifiedCount > 0;
        }
    }
}
