﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;

namespace AuthenticationService.Repository
{
    public class AuthRepository : IAuthRepository
    {
        //Define a private variable to represent AuthDbContext
        private readonly AuthDbContext _context;
        public AuthRepository(AuthDbContext dbContext)
        {
            _context = dbContext;
        }


        //This methos should be used to Create a new User
        public bool CreateUser(User user)
        {
            bool result = false;
            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        //This methos should be used to check the existence of user
        public bool IsUserExists(string userId)
        {
            bool isUserExists = false;
            if (_context.Users.FirstOrDefault(u => u.UserId == userId) != null)
                isUserExists = true;            
            return isUserExists;
        }

        //This methos should be used to Login a user
        public bool LoginUser(User user)
        {
            bool isUserExists = false;

            if (_context.Users.FirstOrDefault(u => u.UserId == user.UserId && u.Password == user.Password) != null)            
                isUserExists = true;
            
            return isUserExists;
        }
    }
}
