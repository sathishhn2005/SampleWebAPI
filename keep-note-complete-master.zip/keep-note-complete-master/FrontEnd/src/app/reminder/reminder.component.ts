import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';
import { ReminderService } from '../services/reminder.service';
import { Reminder } from '../reminder';
import { debug } from 'util';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {

  remindername = new FormControl('', [Validators.required, Validators.minLength(4)]);
  reminderdescription = new FormControl('', [Validators.required, Validators.minLength(4)]);
  remindertype = new FormControl('', [Validators.required, Validators.minLength(4)]);
  message: string;
  showSubmit: boolean;
  reminder: Reminder;
  reminders: Reminder[];

  constructor(private _routerservice: RouterService,
    private _authservice: AuthenticationService,
    private _reminderservice: ReminderService) {
    this.reminder = new Reminder(0, null, null, null,null);
    this.showSubmit=true;
    this.getUserReminders();
  }


  ngOnInit() {
   
  }

  getUserReminders() {
    this._reminderservice.getReminders().subscribe(data => {
      this.reminders = data;
    },
      err => { this.message = err.message })
  }
  submit() {
    const createdby = this._authservice.getLoggedInUserId();
    const reminder = new Reminder(0, this.remindername.value,this.remindertype.value, this.reminderdescription.value, createdby);
    this._reminderservice.createReminders(reminder).subscribe(
      res => {
        this.message = "Reminder Successfully Created";
        this._reminderservice.getRemindersFromServer();
        this.clear();
      },
      err => { this.message = "Reminder Not Created: " + err.message }
    );
  }

  clear() {
    this.remindername = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.reminderdescription = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.remindertype = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.showSubmit=true;
    this.clearMessage();
  }

  getremindernameErrorMessage() {
    return this.reminderdescription.hasError('required') ? 'You must enter a Value' : '';
  }

  getremindertypeErrorMessage() {
    return this.remindertype.hasError('required') ? 'You must enter a Value' : '';
  }
  gereminderdescriptionErrorMessage() {
    return this.reminderdescription.hasError('required') ? 'You must enter a Value' : '';
  }
  clearMessage(){
    this.message='';
  }

  editReminder(ipdata: Reminder) {
    this.clearMessage();
    this.showSubmit=false;
    this._reminderservice.getReminderbyID(ipdata.id).subscribe(data => {
      this.reminder = data;
    },
      err => {
        this.message = "Internal server error";
      })
  }

  update() {
    this.clearMessage();
    const createdby = this._authservice.getLoggedInUserId();
    const updated = new Reminder(this.reminder.id, this.remindername.value,this.remindertype.value, this.reminderdescription.value, createdby);    
    this._reminderservice.editReminder(updated).subscribe(data => {
      this._reminderservice.getRemindersFromServer();
      this.getUserReminders();
      this.showSubmit=true;
      this.clear();
    })
  }

  deleteReminder(ipdata: Reminder) {
    this.clearMessage();
    this._reminderservice.deleteReminder(ipdata).subscribe(data => {
      this._reminderservice.getRemindersFromServer();
    },
      err => {
        this.message = "Internal server error";
      })
  }
}
