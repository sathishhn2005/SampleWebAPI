import { Component, OnInit, Input } from '@angular/core';
import { Note } from '../note';
import { RouterService } from '../services/router.service';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {
  @Input()
  note: Note;
  message: string;

  constructor(private _routerservice: RouterService,
    private _noteservice: NotesService) {
  }

  ngOnInit() {
  }

  openEditView() {
    this._routerservice.routeToEditNoteView(this.note.id);
  }

  deleteNote(note: Note) {
    this._noteservice.DeleteNote(note).subscribe(editNote => {
      this._noteservice.fetchNotesFromServer();
    }
    );
  }
}
