// Angular Modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

// Components
import { HeaderComponent } from './header/header.component';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NoteTakerComponent } from './note-taker/note-taker.component';
import { NoteViewComponent } from './note-view/note-view.component';
import { ListViewComponent } from './list-view/list-view.component';
import { NoteComponent } from './note/note.component';
import { EditNoteOpenerComponent } from './edit-note-opener/edit-note-opener.component';
import { EditNoteViewComponent } from './edit-note-view/edit-note-view.component';
import { CategoryComponent } from './category/category.component';
import { ReminderComponent } from './reminder/reminder.component';
import { RefreshComponent } from './refresh/refresh.component';

// Services
import { NotesService } from './services/notes.service';
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';
import { UserService } from './services/user.service';
import { CategoryService } from './services/category.service';
import { ReminderService } from './services/reminder.service';

// Guards
import { CanActivateRouteGuard } from './can-activate-route.guard';

// Http Modules
import { HttpClientModule } from '@angular/common/http';

// For Material UI Angular Modules
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { RegisterComponent } from './register/register.component';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';



// Router Path & Component Configuration
const approutes: Routes = [
  
  // Default Path (i.e) Startup Path
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // Login Page Path
  {
    path: 'login',
    component : LoginComponent
  },
  {
    path: 'register',
    component : RegisterComponent
  },
  {
    path: 'category',
    component : CategoryComponent,
    canActivate: [CanActivateRouteGuard],
  },
  {
    path: 'reminder',
    component : ReminderComponent,
    canActivate: [CanActivateRouteGuard],
  },
  {
    path: 'refresh',
    component : RefreshComponent,
    canActivate: [CanActivateRouteGuard],
  },
  {
    path: 'dashboard',
    component : DashboardComponent,
    
    canActivate: [CanActivateRouteGuard],
    children : [
      //Default Path for Dashboard
      {
        path: '',
        redirectTo: 'view/noteview',
        pathMatch: 'full'
      },
      {
      path: 'view/noteview',
      component : NoteViewComponent
      },
      {
        path: 'view/listview',
        component : ListViewComponent
      },
     
      {
        path: 'note/:noteId/edit',
        component : EditNoteOpenerComponent,
        outlet : 'noteEditOutlet'
      }
    ]
  }
  
];

@NgModule({
  declarations: [
  AppComponent,
  HeaderComponent,
  LoginComponent,
  DashboardComponent,
  NoteTakerComponent,
  NoteViewComponent,
  ListViewComponent,
  NoteComponent,
  EditNoteViewComponent,
  EditNoteOpenerComponent,
  RegisterComponent,
  CategoryComponent,
  ReminderComponent,
  RefreshComponent
 ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatExpansionModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    RouterModule.forRoot(approutes),
    MatCardModule,
    MatListModule,
    HttpClientModule,
    MatDialogModule,
    MatSelectModule,
    MatSidenavModule,
    MatIconModule
  ],
  providers: [
    NotesService,
    AuthenticationService,
    RouterService,
    UserService,
    CategoryService,
    ReminderService,
    CanActivateRouteGuard
  ],
  bootstrap: [ AppComponent ],
  entryComponents: [ EditNoteViewComponent ]
})

export class AppModule { }



