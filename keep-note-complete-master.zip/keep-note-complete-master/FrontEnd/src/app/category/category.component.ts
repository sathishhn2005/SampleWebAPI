import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';
import { CategoryService } from '../services/category.service';
import { Category } from '../category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  categoryname = new FormControl('', [Validators.minLength(4)]);
  categorydescription = new FormControl('', [Validators.minLength(4)]);
  category: Category;
  categories: Category[];
  message: string;
  showSubmit: boolean;

  constructor(private _routerservice: RouterService,
    private _authservice: AuthenticationService,
    private _categoryservice: CategoryService) {
    this.category = new Category(0, null, null, null);
    this.showSubmit = true;
  }

  ngOnInit() {
    this.getUserCategories();
  }

  getUserCategories() {
    this._categoryservice.getCategories().subscribe(data => {
      this.categories = data;
    },
      err => { this.message = err.message })
  }
  submit() {
    this.clearMessage();
    const createdby = this._authservice.getLoggedInUserId();
    const category = new Category(0, this.categoryname.value, this.categorydescription.value, createdby);
    this._categoryservice.createCategory(category).subscribe(
      res => {
        this.message = "Category Successfully Created";
        this.getUserCategories();
      },
      err => { this.message = "Category Not Created: " + err.message }
    );
  }

  clear() {
    this.categoryname = new FormControl('', [Validators.minLength(4)]);
    this.categorydescription = new FormControl('', [Validators.minLength(4)]);
    this.showSubmit=true;
    this.clearMessage();
  }

  getcategorynameErrorMessage() {
    return this.categoryname.hasError('required') ? 'You must enter a Value' : '';
  }

  getcategorydescriptionErrorMessage() {
    return this.categorydescription.hasError('required') ? 'You must enter a Value' : '';
  }

  editCategory(cat: Category) {
    this.clearMessage();
    this.showSubmit=false;
    this._categoryservice.getCategorybyID(cat.id).subscribe(data => {
      this.category = data;
    },
      err => {
        this.message = "Internal server error";
      })
  }

  update() {
    const createdby = this._authservice.getLoggedInUserId();
    const updated = new Category(this.category.id, this.categoryname.value, this.categorydescription.value, createdby);
    this.clear();
    this._categoryservice.editCategory(updated).subscribe(data => {
      this.getUserCategories();
      this.showSubmit=true;
    })
  }

  deleteCategory(ipdata: Category) {
    this.clearMessage();
    this._categoryservice.deleteCategory(ipdata).subscribe(data => {
      this._categoryservice.getCategoriesFromServer();
    },
      err => {
        this.message = "Internal server error";
      })
  }

  clearMessage(){
    this.message='';
  }
}
