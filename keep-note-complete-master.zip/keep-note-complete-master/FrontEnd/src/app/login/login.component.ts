import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { registerLocaleData } from '@angular/common';
import { User } from '../User';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userId = new FormControl('', [Validators.required]);
  password = new FormControl('', [Validators.required, Validators.minLength(4)]);
  bearertoken: any;
  message: string;

  constructor(
    private _authservice: AuthenticationService,
    private _routerservice: RouterService) {
    }

    submit() {

      // Getting User Id from Front end
      const user = new User(this.userId.value, this.password.value);

      // Passing to Authenication Web API & Receiving token
      // Storing token in local Storage & setting whichh user has logged In
      // Once token recieved it will redirect to dashboard      
      this._authservice.authenticateUser(user).subscribe(
         res => {
           this.bearertoken = res['token'];
           if(this.bearertoken) {
            this._authservice.isUserlogIn(); }
           this._authservice.setBearerToken(this.bearertoken);
           localStorage.setItem('usertoken', this.bearertoken);
           this._authservice.setLoggedInUserId(user.userId);
           this._routerservice.routeToDashboard();
          }, 
          err => { this.message = err.error;  }
        );
    }

    edit() {

      // Getting User Id from Front end
      const user = new User(this.userId.value, this.password.value);

      // Passing to Authenication Web API & Receiving token
      // Storing token in local Storage & setting whichh user has logged In
      // Once token recieved it will redirect to dashboard      
      this._authservice.authenticateUser(user).subscribe(
         res => {
           this.bearertoken = res['token'];
           if(this.bearertoken) {
            this._authservice.isUserlogIn(); }
           this._authservice.setBearerToken(this.bearertoken);
           localStorage.setItem('usertoken', this.bearertoken);
           this._authservice.setLoggedInUserId(user.userId);
           //To Be Modified
           //this._routerservice.routeToRegister();
           this._routerservice.routeToEditProfile(user);
          }, 
          err => { this.message = err.error;  }
        );
    }

    // For New Registration Redirecting to Register Page
    register() {
      // const user = new User(this.userId.value, this.password.value);
      // this._authservice.authenticationRegisterUser(user, 0).subscribe(
      //   res => {
      //     this._routerservice.routeToRegister();
      //   },
      //   err => { this.message = err.error;  }
      // ); 
       this._routerservice.routeToRegister();     
    }

    getUserNameErrorMessage() {
     return this.userId.hasError('required') ? 'You must enter a value' : '';
    }

    getPasswordErrorMessage() {
      return this.password.hasError('required') ? 'You must enter a value' : '' ;
    }
}
