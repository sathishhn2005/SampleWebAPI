export class Register {
    userId: string;
    password: string;
    name:string;
    contact:string;


    constructor(userId, password, firstname, lastname, contact) {
      this.userId = userId;
      this.password = password;
      this.name = firstname + " " +lastname;
      this.contact = contact;     
    }
}
