export class Category {
    id: number;
    name: string;
    description: string;
    createdBy :string;


  constructor(id, name, description, createdBy) {
      this.id = id;
      this.name = name;
      this.description = description;
      this.createdBy = createdBy;
    }


}
