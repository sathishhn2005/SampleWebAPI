import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { registerLocaleData } from '@angular/common';
import { Register } from '../register';
import { RouterService } from '../services/router.service';
import { UserService } from '../services/user.service';
import { User } from '../User';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: Register;
  titleValue: string;
  userValue: string;
  authuser: User;
  UserId = new FormControl('', [Validators.required, Validators.minLength(4)]);
  password = new FormControl('', [Validators.required, Validators.minLength(4)]);
  firstname = new FormControl('', [Validators.required, Validators.minLength(4)]);
  lastname = new FormControl('', [Validators.required, Validators.minLength(4)]);
  contact = new FormControl('', [Validators.required, Validators.minLength(4)]);
  myform: FormGroup;
  message: string;
  bearertoken: any;
  showValue: boolean;
  userName: string;
  editUserId: boolean;
  //docker -compose up
  constructor(

    private _routerservice: RouterService,
    private _userService: UserService,
    private _route: ActivatedRoute,
    private _authService: AuthenticationService) {
    this.user = new Register(0, null, null, null, null);
    
    this.editUserId = false;
    this.titleValue = "Registration";
  }

  ngOnInit() {
    
    const userName = this._route.snapshot.queryParamMap.get('userName');
    this.userValue = "Welcome " + this._authService.getLoggedInUserId();
    if (userName != null && userName != undefined) {      
      // const password = this._route.snapshot.queryParamMap.get('pswd');
      this._userService.getUserById(userName).subscribe(data => {
        this.user = data;
        this.showValue = true;
        this.UserId.setValue(this.user.userId);
        let Name = this.user.name.split(" ");
        this.firstname.setValue(Name[0]);
        this.lastname.setValue(Name[1]);
        this.contact.setValue(this.user.contact);
      },
        err => {
          this.message = "Internal server error";
        })
    }
    else
    {
      this.showValue = false;
      this.titleValue = "Edit Profile"; 
    }
  }

  register() {
    const authuser = new User(this.UserId.value, this.password.value);
    const user = new Register(this.UserId.value, this.password.value, this.firstname.value, this.lastname.value, this.contact.value);
    this._authService.authenticationRegisterUser(authuser).subscribe(
      res => {
        if (res) {
          this._authService.authenticateUser(authuser).subscribe(
            res => {
              this.bearertoken = res['token'];
              this._authService.setBearerToken(this.bearertoken)
              this._userService.registerUser(user).subscribe(
                res => { this.message = "User Successfully Registered" },
                err => { this.message = "User Not Registered: " + err.error }
              );

            },
            err => { this.message = "User Not Registered: " + err.error }
          );
        }
      },
      err => { this.message = "User Not Registered: " + err.error }
    );
  }

  editUser(userToUpdate: Register) {
    this.showValue = true;
    this.editUserId = true;
    this.titleValue = "Edit Profile";    
    this._userService.getUserById(userToUpdate.userId).subscribe(data => {
      this.user = data;
    },
      err => {
        this.message = "Internal server error";
      })
  }

  update() {
    const updated = new Register(this.UserId.value, this.password.value, this.firstname.value, this.lastname.value, this.contact.value);
    this.clear();
    debugger;
    this._userService.editProfile(updated).subscribe(data => {
      this.message = "Profile successfully updated";
    },
    err => {
      this.message = "User not updated. Please try again";
    })
  }

  clear() {
    this.UserId = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.password = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.firstname = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.lastname = new FormControl('', [Validators.required, Validators.minLength(4)]);
    this.contact = new FormControl('', [Validators.required, Validators.minLength(4)]);
  }

  login() {
    this._routerservice.routeToLogin();
  }

  getUserIdErrorMessage() {
    return this.UserId.hasError('required') ? 'You must enter a Value' : '';
  }

  getPasswordErrorMessage() {
    return this.lastname.hasError('required') ? 'You must enter a Value' : '';
  }

  getFirstNameErrorMessage() {
    return this.firstname.hasError('required') ? 'You must enter a Name' : '';
  }

  getLastErrorMessage() {
    return this.lastname.hasError('required') ? 'You must enter a Name' : '';
  }

  getcontactErrorMessage() {
    return this.contact.hasError('required') ? 'You must enter a value' : '';
  }

}
