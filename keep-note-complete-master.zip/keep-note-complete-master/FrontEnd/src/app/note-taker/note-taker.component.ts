import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';
import { CategoryService } from '../services/category.service';
import { Category }  from '../category';
import { ReminderService } from '../services/reminder.service';
import { Reminder }  from '../reminder';
import { AuthenticationService } from '../services/authentication.service';
import { convertToParamMap } from '@angular/router';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent  implements OnInit {

  errMessage: string;
  userName: string;
  note: Note = new Note();
  notes: Array<Note> = [];
  category: Category ;
  categoryID: Number;
  categories: Array<Category>;
  Reminders: Array<Reminder>;

  constructor(private _noteService: NotesService, 
    private routeService : RouterService , 
    private _categoryService : CategoryService, 
    private _reminderService :ReminderService,
    private _authService : AuthenticationService) {
    this.note = new Note();
    this.notes = [];
    this.errMessage = '';
    this.getCategoriesFromServer(); 
    this.getRemindersFromserver();    
   }

  ngOnInit() {
    this.userName = "Welcome " + this._authService.getLoggedInUserId();
  }

  getCategoriesFromServer() {
    this._categoryService.getCategories().subscribe(
    categories => { this.categories = categories;},
    err => { this.errMessage = err.error.message;}
    );
  }

  getRemindersFromserver() {
     this._reminderService.getReminders().subscribe(
       Reminders => { this.Reminders = Reminders;},
       err => { this.errMessage = err.error.message;}
     );
  }
 

  takeNotes() {
    if (this.note.title.trim().toString() === '' || this.note.content.trim().toString() === '') {
      // Tilte and Text blank Validation
      this.errMessage = 'Title and Content both are required fields';
    } else {              
         this._categoryService.getCategorybyID(this.note.category.id).subscribe(
          Category => { 
          this.note.category = Category;            
              this._reminderService.getReminderbyID(this.note.reminder.id).subscribe(
              Reminders => { 
              this.note.reminder = Reminders;                 
                this.note.createdBy = this._authService.getLoggedInUserId();
                this.notes.push(this.note);
                this._noteService.addNote(this.note).subscribe(
                  data => {},
                  err => {
                  const index = this.notes.findIndex(note => note.title === this.note.title);
                  this.notes.splice(index, 1);
                  this.errMessage = err.message;
                  }
                );
                this.note = new Note(); 
              },
              err => { this.errMessage = err.error.message;}
            );                                                                     
          },
          err => { this.errMessage = err.error.message;}
        );       
    }
  }

  
}
