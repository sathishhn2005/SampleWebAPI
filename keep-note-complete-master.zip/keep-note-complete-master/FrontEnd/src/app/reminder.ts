export class Reminder {
    id: Number;  
    name: string;
    type:string;
    description: string;
    createdBy :string;


  constructor(id, name,type, description, createdBy) { 
      this.id = id;   
      this.name = name;
      this.type=type;
      this.description = description;
      this.createdBy = createdBy;
    }

}
