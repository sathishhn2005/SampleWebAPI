import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RouterService } from '../services/router.service';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  displayView: boolean = false;
  isNoteView = true;
  isUserloggedIn$: Observable<boolean>;

  constructor(
    private _router: Router,
    private _routerService: RouterService,
    private _authservice: AuthenticationService) {
    this.displayView = false;
  }

  ngOnInit() {


    const token = this._authservice.getBearerToken();
    if (token != null) {
      this._authservice.isUserlogIn()
      this.isUserloggedIn$ = this._authservice.isUserLoggedIn;
      const isUserloggedIn = this.isUserloggedIn$;
    }
  }

  navLogout() {
    this._authservice.logoutUser();
    this._routerService.routeToLogin();
  }

  navDashboard() {
    this._routerService.routeToDashboard();
  }


  navCategory() {
    this._routerService.routeToCategory();
  }

  navReminder() {
    this._routerService.routeToReminder();
  }
}
