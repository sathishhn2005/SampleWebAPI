import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { Category } from '../category';
import { CategoryService } from '../services/category.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-note-view',
  templateUrl: './note-view.component.html',
  styleUrls: ['./note-view.component.css']
})
export class NoteViewComponent implements OnInit {
  errMessage: string;
  note: Note = new Note();
  notes: Array<Note>;


  constructor(private noteService: NotesService,     
    private _authenticationservice :AuthenticationService) {

    this.noteService.getNotes().subscribe(
      data => this.notes = data,
      err => {
        if (err.message.includes('404')) {
          this.errMessage = err.message;
        } else {
          this.errMessage = err.error.message;
        }
      }
    );    
  }

  ngOnInit() {
  }
}
