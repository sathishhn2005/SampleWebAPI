import { Category } from "./category";
import { Reminder } from "./reminder";

export class Note {
  id: Number;
  title: string;
  content: string;
  createdBy:string;
  category: Category;
  reminder: Reminder;
  /*state: string;*/

  constructor() {
    this.title = '';
    this.content = '';
    this.createdBy = '';
    this.category = new Category(null,null,null,null);
    this.reminder = new Reminder(null,null,null,null,null)
    /*this.state = 'not-started';*/
  }
}
