import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';
import { Category } from '../category';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class CategoryService {

  categories: Array<Category>;
  categoriesSubject: BehaviorSubject<Array<Category>>;
  constructor(private httpClient: HttpClient, private _authservice: AuthenticationService
  ) {
    this.categories = [];
    this.categoriesSubject = new BehaviorSubject<Array<Category>>([]);
    this.getCategoriesFromServer();
  }

  createCategory(data: Category) {
    const token = this._authservice.getBearerToken();
    return this.httpClient.post<Category>("http://localhost:58087/api/category", data, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${token}`)
    }).pipe(tap(addCategory => {
      this.categories.push(addCategory);
      this.categoriesSubject.next(this.categories);
    }))
  }

  getCategoriesFromServer() {
    const createdby = this._authservice.getLoggedInUserId();
    const token = this._authservice.getBearerToken();
    return this.httpClient.get<Category[]>('http://localhost:58087/api/category/' + this._authservice.getLoggedInUserId(),
      {
        headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
      }).subscribe(categories => {
        this.categories = categories;
        this.categoriesSubject.next(this.categories);
      })

  }

  getCategorybyID(data): Observable<Category> {
    const token = this._authservice.getBearerToken();
    return this.httpClient.get<Category>('http://localhost:58087/api/category/' + data, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    });
  }

  editCategory(category: Category): Observable<Category> {
    var id = category.id;
    const token = this._authservice.getBearerToken();
    return this.httpClient.put<Category>(`http://localhost:58087/api/category/${id}`, category,
      { headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` }) }
    ).pipe(tap(editCategory => {
      const foundCategory = this.categories.find(a => a.id == editCategory.id);
      Object.assign(foundCategory, editCategory);
      this.categoriesSubject.next(this.categories);
    }));
  }

  getCategories(): BehaviorSubject<Array<Category>> {
    return this.categoriesSubject;
  }

  deleteCategory(category: Category) {
    var id = category.id;
    const token = this._authservice.getBearerToken();
    return this.httpClient.delete(`http://localhost:58087/api/category/${id}`,
      { headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` }) });
  }
}
