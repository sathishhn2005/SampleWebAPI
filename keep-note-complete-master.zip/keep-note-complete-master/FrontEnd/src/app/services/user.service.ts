import { Injectable } from '@angular/core';
import { User } from '../User';
import { Register } from '../register';
import { Observable } from 'rxjs/Observable';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService} from '../services/authentication.service';
import { tap } from 'rxjs/operators';

@Injectable()
export class UserService {

  profile: Array<User>;
  
  constructor(private httpClient : HttpClient, private  _authservice : AuthenticationService) {
    this.profile = []; 
   }

 
  registerUser(data){
    const token = this._authservice.getBearerToken();
    return this.httpClient.post("http://localhost:63516/api/user/register", data,  {
      headers : new HttpHeaders()
      .set('Authorization',`Bearer ${token}`)
    });       
  }

  //Modified Now
  getUserById(userId){
    const token = this._authservice.getBearerToken();
    localStorage.setItem('UserIdSearched',userId);
    return this.httpClient.get<Register>('http://localhost:63516/api/user/' + userId, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    });
  }

  //Modified Now
  editProfile(user: User): Observable<User> {
    var userId = user.userId;
    const token = this._authservice.getBearerToken();
    return this.httpClient.put<User>(`http://localhost:63516/api/user/${userId}`, user,
      { headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` }) }
      );
      // .pipe(tap(editProfile => {
      //   const foundProfile = this.profile.find(a => a.userId == this.editProfile.userId);
      //   Object.assign(foundProfile, editProfile);        
      //})); 
  }
}
