import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import 'rxjs/add/operator/map';
import { t } from '@angular/core/src/render3';

@Injectable()
export class AuthenticationService {
  
  //For Checking Whether the user has logged in (By Default it will be loggedout state (false))
  private isUserloggedIn = new BehaviorSubject<boolean>(false);
  public isAuth: boolean;

  constructor(private httpClient: HttpClient) {
  }

  // For Checking Whether the user has logged in 
  get isUserLoggedIn() {
    return this.isUserloggedIn.asObservable(); 
  }

  logoutUser()
  { // Clearing Local Storage (Session Varibles) & Changing isUserloggedIn=false (since user has logged out)
    localStorage.removeItem("UserId");
    localStorage.clear();
    this.isUserloggedIn.next(false);
  }

  //If user logged in he will receive token from WebAPI through JWT
  //Setting Bearer Token
  setBearerToken(token) {    
    localStorage.setItem('bearerToken', token);    
  }
  
  //Changing isUserloggedIn=false (since user has logged out)
  isUserlogIn(){
      this.isUserloggedIn.next(true);
  }

   //Changing isUserloggedIn=false (since user has logged out)
   isUserlogOut(){
       this.isUserloggedIn.next(false);
   }

  //Getting Bearer Token
  getBearerToken() {
    return(localStorage.getItem('bearerToken'));
  }
  
  isUserAuthenticated(token: string): Promise<boolean> {  
    return this.httpClient.post('http://localhost:50740/api/auth/isAuthenticated', {}, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    }).map((response) => response['isAuthenticated']).toPromise();         
  }

  setLoggedInUserId(UserId) {
    localStorage.removeItem("UserId");
    localStorage.setItem("UserId",UserId);
    }
  getLoggedInUserId(){
      console.log("Get loggedin user :" + localStorage.getItem("UserId") )
      return localStorage.getItem("UserId");
    }

  authenticateUser(data) {    
    return this.httpClient.post('http://localhost:50740/api/auth/login', data);    
  }

  
  authenticationRegisterUser(data){
    debugger;
    return this.httpClient.post("http://localhost:50740/api/auth/register", data);          
  }

  

}
