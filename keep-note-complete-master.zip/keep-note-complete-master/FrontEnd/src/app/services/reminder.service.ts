import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';
import { Reminder } from '../reminder';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable()
export class ReminderService {

  reminders: Array<Reminder>;
  remindersSubject: BehaviorSubject<Array<Reminder>>;


  constructor(private httpClient: HttpClient, private _authservice: AuthenticationService) {
  this.reminders = [];
    this.remindersSubject = new BehaviorSubject<Array<Reminder>>([]);
    this.getRemindersFromServer();
  }

  createReminders(data) {
    const token = this._authservice.getBearerToken();
    return this.httpClient.post<Reminder>("http://localhost:49595/api/reminder", data, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${token}`)
    }).pipe(tap(addReminder => {
      this.reminders.push(addReminder);
      this.remindersSubject.next(this.reminders);
    }))
  }


  getRemindersFromServer() {
    const createdby = this._authservice.getLoggedInUserId();
    const token = this._authservice.getBearerToken();
    return this.httpClient.get<Reminder[]>('http://localhost:49595/api/reminder/' + this._authservice.getLoggedInUserId(),
      {
        headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
      }).subscribe(reminders => {
        this.reminders = reminders;
        this.remindersSubject.next(this.reminders);
      })

  }


  getReminderbyID(data) {
    const token = this._authservice.getBearerToken();
    return this.httpClient.get<Reminder>('http://localhost:49595/api/reminder/' + data, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    });
  }
  editReminder(reminder: Reminder): Observable<Reminder> {
    var id = reminder.id;
    const token = this._authservice.getBearerToken();
    return this.httpClient.put<Reminder>(`http://localhost:49595/api/reminder/${id}`, reminder,
      { headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` }) }
    ).pipe(tap(editReminder => {
      const foundCategory = this.reminders.find(a => a.id == editReminder.id);
      Object.assign(foundCategory, editReminder);
      this.remindersSubject.next(this.reminders);
    }));
  }

  getReminders(): BehaviorSubject<Array<Reminder>> {
    return this.remindersSubject;
  }

  deleteReminder(reminder: Reminder) {
    var id = reminder.id;
    const token = this._authservice.getBearerToken();
    return this.httpClient.delete(`http://localhost:49595/api/reminder/${id}`,
      { headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` }) });
  }

}
