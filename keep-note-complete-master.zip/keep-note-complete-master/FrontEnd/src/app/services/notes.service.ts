import { Injectable } from '@angular/core';
import { Note } from '../note';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { AuthenticationService } from './authentication.service';
import 'rxjs/add/operator/do';

@Injectable()
export class NotesService {
  token: any;
  notes: Array<Note>;
  notesSubject: BehaviorSubject<Array<Note>>;

  constructor(private http: HttpClient,
              private _authservice: AuthenticationService) {
                this.notes = [];
                this.notesSubject = new BehaviorSubject(this.notes);
  }



  fetchNotesFromServer() {
    const token = this._authservice.getBearerToken();
    const createdby= this._authservice.getLoggedInUserId();
    return this.http.get<Note[]>('http://localhost:50367/api/notes/' + createdby,
      {
        headers: new HttpHeaders().set('Authorization',`Bearer ${token}`)
      }).subscribe(notes => {
        this.notes = notes;
        this.notesSubject.next(this.notes);      
      });
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }

  addNote(note: Note): Observable<Note> {
    const token = this._authservice.getBearerToken();
    const createdby= this._authservice.getLoggedInUserId();
    return this.http.post<Note>('http://localhost:50367/api/notes/' + createdby, note, {
      headers: new HttpHeaders().set('Authorization',`Bearer ${token}`)
    }).do(noteAdded => {
      this.notes.push(noteAdded);
      this.notesSubject.next(this.notes);
    });
  }

  editNote(note: Note): Observable<Note> {
    const token = this._authservice.getBearerToken();
    const createdby= this._authservice.getLoggedInUserId();
    return this.http.put<Note>('http://localhost:50367/api/notes/'+ createdby +'/' + note.id , note, {
      headers: new HttpHeaders().set('Authorization',`Bearer ${token}`)
    }).do(addedNote => {
      const selectedNote = this.notes.find((currentNote) => currentNote.id === addedNote.id);
      Object.assign(selectedNote, addedNote);
      this.notesSubject.next(this.notes);
    });
  }

  getNoteById(noteId): Note {
    return this.notes.find(note => note.id === noteId);
  }


  DeleteNote(note:Note):  Observable<void> {
    const token = this._authservice.getBearerToken();
    const createdby= this._authservice.getLoggedInUserId();
    return this.http.delete<void>('http://localhost:50367/api/notes/' + createdby  +'/' + note.id , {
      headers: new HttpHeaders().set('Authorization',`Bearer ${token}`)
    });
  }
}
