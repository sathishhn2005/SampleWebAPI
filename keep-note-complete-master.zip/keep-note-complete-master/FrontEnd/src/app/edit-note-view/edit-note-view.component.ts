import { Component, OnInit, Inject } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CategoryService } from '../services/category.service';
import { Category } from '../category';
import { ReminderService } from '../services/reminder.service';
import { Reminder } from '../reminder';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {
  note: Note;
  categories: Array<Category>;
  reminders: Array<Reminder>;
  selectedReminder: Number;
  selectedCategory: Number;
  errMessage: string;

  constructor(
    private dialog: MatDialogRef<EditNoteViewComponent>,
    private notesService: NotesService,
    private routeService: RouterService,
    private categoryService: CategoryService,
    private reminderService: ReminderService,
    @Inject(MAT_DIALOG_DATA) private data: any) {
    this.getCategoriesFromServer();
    this.getRemindersFromserver();
  }

  ngOnInit() {
    this.note = this.notesService.getNoteById(this.data.noteId);
    if (this.note.category != null) {
      this.selectedCategory = this.note.category.id;
    }
    if (this.note.reminder != null) {
      this.selectedReminder = this.note.reminder.id;
    }
    this.categoryService.getCategories().subscribe(
      data => this.categories = data,
      err => {
        console.error(err);
      });
    this.reminderService.getReminders().subscribe(
      data => { this.reminders = data; },
      err => {
        console.error(err);
      });
  }

  onSave() {
    const note: Note = new Note();
    note.id = this.note.id;
    note.title = this.note.title;
    note.content = this.note.content;
    this.categoryService.getCategorybyID(this.selectedCategory).subscribe(data => {
      note.category = data;
      this.reminderService.getReminderbyID(this.selectedReminder).subscribe(data => {
        note.reminder = data;
        this.notesService.editNote(note).subscribe(editNote => {
          this.dialog.close();
          this.routeService.routeToListView();
          this.routeService.routeToNoteView();
          this.notesService.getNotes();
        }, err => {
          this.errMessage = err.message;
        });
      })
    });
  }

  close() {
    this.dialog.close();
  }
  getCategoriesFromServer() {
    this.categoryService.getCategories().subscribe(
      categories => { this.categories = categories; },
      err => { this.errMessage = err.error.message; }
    );
  }

  getRemindersFromserver() {
    this.reminderService.getReminders().subscribe(
      Reminders => { this.reminders = Reminders; },
      err => { this.errMessage = err.error.message; }
    );
  }

}
